package AppMusic


//Polymorphism & Inheritance - Session 4

class Expectation(name: String, strength: Int):
    Lucidity("Expectation", 1 ) {
    init {
        println("Play Another Song For Me $name")
    }
}




