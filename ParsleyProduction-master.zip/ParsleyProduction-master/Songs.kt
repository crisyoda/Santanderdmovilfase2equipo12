package AppMusic


//Playlist



val songs = listOf (

    "Half Full Glass of Wine",
    "Solitude Is Bliss",
    "Lucidity",
    "Expectation",
    "Elephant",
    "Feels Like We Only Go Backwards",
    "Mind Mischief",
    "Cause I'm a Man",
    "Let It Happen",
    "The Less I Know the Better",
    "Lost in Yesterday",
    "Is It True",
    "Breathe Deeper",
    )






